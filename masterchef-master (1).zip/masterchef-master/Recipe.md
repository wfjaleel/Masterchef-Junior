Mince the onion and then mix it with ground chicken, chilli powder, pepper powder, salt, egg, and the bread crumbs.
Once you have mixed the above ingredients, shape them into patties and then shallow fry them. Once the meat is cooked, keep the burgers aside.
Now take the hamburger bread, and coat it with mayonnaise. Then keep the burger on top of one slice of the bread. Next put a slice of tomato and onion over this burger. Put the slice of American cheese and pickled stacker.
Next, put the other slice of the hamburger bread.