# Master-chef

The recipe is to create a Chicken burger.