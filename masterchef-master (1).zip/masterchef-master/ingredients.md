1 pound - ground chicken
1 - medium-sized onion
1 - egg
1 tsp - red chilli powder
Salt
1 tsp - pepper powder
Bread crumbs
Oil for frying
Hamburger buns - as needed
Hamburger stacker pickle
1 - tomato
Mayonnaise
American sliced cheese